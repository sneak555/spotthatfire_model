/**
 * 
 */
/**
 * @author Ben
 *
 */
module windmap2D {
	requires java.desktop;
}