/*
 * spaceapps hackathon, "spothatfire" algorithm.
 */
package frontend;

import backend.windmap;

/*
 * This is the main driver, it runs the other classes/methods/etc to run a basic/wrong(?) fire propagation.
 */

/**
 * 
 * @author Benjamin De Jager, Steven Fischbach
 * @version 0.1.2
 * date:10/19/2019
 */
public class Windmap_Driver {
	
	/*
	 * These two are constants that are used as the size of the wind-map.
	 */
	private final static int sizeX = 12;
	private final static int sizeY = 12;
	
	private static windmap theMap;
	
	/*
	 * This is the main method to run this windmap program.
	 */
	public static void main(String[] args) {
		intro();
		// create the windmap.
		theMap = new windmap(sizeX, sizeY);

		//print out the default-map for comparison and then edit two sample points.
		theMap.printMap();
		theMap.setWind(3, 5, 10, 10);
		
		/*
		 * this is a weird model as it treats "wind" more like it is temp/heat/energy spreading across a array of points. 
		 * run the main method in a java-IDE to see a map-print out that first prints out a default all-zeros map and 
		 * then modifys a example points. this model has a couple bugs that I'm still fixing in regards to the size/points.
		 * 
		 * it then prints out each following tick of the simulation that results from that change.
		 */
		
		//print out the new map.
		theMap.printMap();
		//run 10 ticks of propagation/simulation.
		doXTicks(10);
	}
	
	/*
	 * basic introduction. says little of value.
	 */
	private static void intro() {
		System.out.println("windmapV0.1");
		return;
	}
	
	/*
	 * This method runs X ticks of simulation as given as a int.
	 */
	private static void doXTicks(int X) {
		for (int i = 0;i < X;i++)
			doOneTick();
	}
	
	/*
	 * This method runs exactly one tick of simulation and prints out the map each time.
	 */
	private static void doOneTick() {
		theMap.propagateOneTick();
		theMap.printMap();
	}
}
